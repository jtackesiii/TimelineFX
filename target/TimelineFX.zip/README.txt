TimelineFX
(c) 2020 Nick Tackes

To run the program:

1. Extract the contents of the .ZIP folder where you would like the program.

2. Inside the folder, navigate to the "bin" folder.

3. Locate the "TimelineFX.bat" file (Windows Batch file).

4. Double-click and enjoy!

To use the included logo:

1. Navigate to /bin/ >> TimelineFX.bat

2. Right-click, and "create shortcut".

3. Right-click the shortcut, and click "properties" >> "change icon"

4. Navigate to /bin/logo.ico and select.

Notes:

1. If using special characters does not work for your timeline, you may need to change your default ".txt" file reader from Notepad to a program such as Notepad++.

2. The character sequence "%%" will break the program when used in event titles or descriptions; please avoid using it.