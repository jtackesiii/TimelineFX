TimelineFX
(c) 2020 Nick Tackes

To run the program:

1. Extract the contents of the .ZIP folder where you would like the program.

2. Inside the folder, navigate to the "bin" folder.

3. Locate the "TimelineFX.bat" file (Windows Batch file).

4. Double-click and enjoy!